from fastapi import FastAPI, HTTPException
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api.formatters import WebVTTFormatter
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="Transcript Converter API")

class TranscriptRequest(BaseModel):
    video_id: str
    language: Optional[str] = 'es'

class TranscriptResponse(BaseModel):
    converted_text: str

def convert_time_format(text: str) -> str:
    # Function to convert time format
    def convert_time(time_str):
        # Remove milliseconds and keep only hours:minutes:seconds
        return time_str.split('.')[0]

    # Split the text into lines and process
    lines = text.split('\n')
    result_parts = []
    
    i = 0
    while i < len(lines):
        if '-->' in lines[i]:
            # Get time range
            start_time, end_time = lines[i].split(' --> ')
            time_str = f"{convert_time(start_time)} -> {convert_time(end_time)}"
            # Get next line (subtitle text)
            if i + 1 < len(lines):
                subtitle_text = lines[i + 1].strip()
                if subtitle_text:  # Only add if there's actual text
                    result_parts.append(f"{time_str} {subtitle_text}")
                i += 1
        i += 1

    # Join all parts with a single space
    return ' '.join(part for part in result_parts if part.strip())

@app.post("/convert-transcript/", response_model=TranscriptResponse)
async def convert_transcript(request: TranscriptRequest):
    try:
        # Get transcript from YouTube
        transcript = YouTubeTranscriptApi.get_transcript(request.video_id, languages=[request.language])
        
        # Format to WebVTT
        formatter = WebVTTFormatter()
        text = formatter.format_transcript(transcript)
        
        # Remove WEBVTT header
        text = text.replace("WEBVTT", "")
        
        # Convert time format
        converted_text = convert_time_format(text)
        
        return {"converted_text": converted_text}
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/")
async def root():
    return {"message": "Welcome to Transcript Converter API. Use POST /convert-transcript/ to convert YouTube transcripts."}
